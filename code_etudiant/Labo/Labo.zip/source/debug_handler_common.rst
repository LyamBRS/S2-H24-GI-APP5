.. image:: ./images/UdeS_logo_h_pms347-crop.jpg
    :width: 200

|

Module debug\_handler\_common
=============================

Diagramme de classe
-------------------

.. uml:: debug_handler_common
   :classes:

Code du module
--------------

.. automodule:: debug_handler_common
   :members:
   :undoc-members:
   :show-inheritance:


.. note::
   Documentation créée le |today|.