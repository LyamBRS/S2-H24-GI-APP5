.. image:: ./images/UdeS_logo_h_pms347-crop.jpg
    :width: 200

|

Module smart\_formatter\_common
===============================

Diagramme de classe
-------------------

.. uml:: smart_formatter_common
   :classes:

Code du module
--------------

.. automodule:: smart_formatter_common
   :members:
   :undoc-members:
   :show-inheritance:


.. note::
   Documentation créée le |today|.