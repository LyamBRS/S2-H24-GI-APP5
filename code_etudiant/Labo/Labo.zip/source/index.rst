.. Labo_GIF270 documentation master file, created by
   sphinx-quickstart on Sun Jan  9 19:30:22 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. image:: ./images/UdeS_logo_h_pms347-crop.jpg
   :width: 200

|

Bienvenue - Documentation du labo GIF270
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contenus:

   debug_handler_common
   handle_unicode_common
   labo_prob1
   labo_prob1_common
   labo_prob2
   labo_prob2_common
   labo_prob3
   labo_prob3_common
   labo_prob4
   labo_prob4_common
   smart_formatter_common
   modules

Index et tableaux
-----------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. note::
   Documentation créée le |today|.
