.. image:: ./images/UdeS_logo_h_pms347-crop.jpg
    :width: 200

|

Module handle\_unicode\_common
==============================

Diagramme de classe
-------------------

.. uml:: handle_unicode_common
   :classes:

Code du module
--------------

.. automodule:: handle_unicode_common
   :members:
   :undoc-members:
   :show-inheritance:


.. note::
   Documentation créée le |today|.