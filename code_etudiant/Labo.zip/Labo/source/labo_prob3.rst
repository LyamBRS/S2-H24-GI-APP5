.. image:: ./images/UdeS_logo_h_pms347-crop.jpg
    :width: 200

|

Module labo\_prob3
==================

Diagramme de classe
-------------------

.. uml:: labo_prob3
   :classes:

Code du module
--------------

.. automodule:: labo_prob3
   :members:
   :undoc-members:
   :show-inheritance:

.. note::
   Documentation créée le |today|.